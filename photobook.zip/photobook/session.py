current_user = {
    "id": None,
    "username": None
}

def is_logged_in():
    return current_user["id"] is not None

def logout():
    current_user["id"] = None
    current_user["username"] = None

def get_user():
    return current_user if is_logged_in() else None